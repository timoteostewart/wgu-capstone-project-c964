DATA_DIR = "L:/Dropbox/proj/capstone-embedder/"

# machine-learning parameters
num_positive = 1024
MINIMUM_FREQUENCY_FOR_WIKILINKS = 5
