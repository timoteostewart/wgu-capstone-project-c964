# Third-party
import numpy as np
from keras.layers import Dense, Dot, Embedding, Input, Reshape
from keras.models import Model

# First-party/Local
import my_data


def book_embedding_model(embedding_size=50):
    book = Input(name="book", shape=[1])
    link = Input(name="link", shape=[1])

    book_embedding = Embedding(
        name="book_embedding", input_dim=len(my_data.books_id_to_name), output_dim=embedding_size
    )(book)

    link_embedding = Embedding(
        name="link_embedding", input_dim=len(my_data.wikilink_id_to_name), output_dim=embedding_size
    )(link)

    merged = Dot(name="dot_product", normalize=True, axes=2)([book_embedding, link_embedding])

    merged = Reshape(target_shape=[1])(merged)

    model = Model(inputs=[book, link], outputs=merged)
    model.compile(optimizer="Adam", loss="mse")

    return model


def find_similar(name, weights, n=10):
    index = my_data.books_name_to_id
    rindex = my_data.books_id_to_name

    # verify `name` is in the index
    try:
        dists = np.dot(weights, weights[index[name]])
    except KeyError:
        print(f"{name} wasn't found.")
        return

    sorted_dists = np.argsort(dists)
    closest = sorted_dists[-n:]

    print(f"Books closest to {name} by {my_data.books_id_to_author[index[name]]}.\n")

    for c in reversed(closest):
        title = rindex[c]
        author = my_data.books_id_to_author[c]
        print(f"Book: {title} by {author} (similarity score: {dists[c]:.2f})")
