# Standard library
import json
import os
import pickle
import random

# Third-party
import numpy as np

# First-party/Local
import config

books_json_filename = "books.json"
wikilinks_json_filename = "wikilinks.json"

books = []
books_id_to_name = dict()
books_id_to_author = dict()
books_name_to_id = dict()

wikilink_name_to_id = dict()
wikilink_id_to_name = dict()


def produce_pairs(min_frequency_for_wikilinks):
    with open(os.path.join(config.DATA_DIR, books_json_filename), mode="r", encoding="utf-8") as fin:
        books.extend(json.load(fin)["books"])

    with open(os.path.join(config.DATA_DIR, wikilinks_json_filename), mode="r", encoding="utf-8") as fin:
        list_of_all_wikilinks = json.load(fin)["wikilinks"]

    for wikilink in list_of_all_wikilinks:
        if int(wikilink["wikilink"]["frequency"]) >= min_frequency_for_wikilinks:
            wikilink_name_to_id[wikilink["wikilink"]["content"]] = wikilink["link_id"]
            wikilink_id_to_name[wikilink["link_id"]] = wikilink["wikilink"]["content"]

    pairs = []

    for book in books:
        book_id = book["book_id"]

        books_id_to_name[book_id] = book["book_data"]["name"]
        books_name_to_id[book["book_data"]["name"]] = book_id
        try:
            books_id_to_author[book_id] = book["book_data"]["author"]
        except KeyError as e:
            books_id_to_author[book_id] = "not_found"

        this_books_wikilinks = book["book_data"]["wikilinks"]

        for each_link in this_books_wikilinks:
            if each_link in wikilink_name_to_id:
                pairs.append(
                    (
                        book_id,
                        wikilink_name_to_id[each_link],
                    )
                )

    # with open("books_id_to_name_dict.pickle", mode="ab") as fout:
    #     pickle.dump(books_id_to_name, fout)

    # with open("books_id_to_author_dict.pickle", mode="ab") as fout:
    #     pickle.dump(books_id_to_author, fout)

    # with open("books_name_to_id_dict.pickle", mode="ab") as fout:
    #     pickle.dump(books_name_to_id, fout)

    # with open("wikilink_name_to_id_dict.pickle", mode="ab") as fout:
    #     pickle.dump(wikilink_name_to_id, fout)

    # with open("wikilink_id_to_name_dict.pickle", mode="ab") as fout:
    #     pickle.dump(wikilink_id_to_name, fout)

    pairs_set = set()
    pairs_set.update(pairs)

    pairs_list = list()
    pairs_list.extend(pairs_set)

    return pairs_list, pairs_set


def generate_batch(pairs_list, pairs_set, n_positive=50, negative_ratio=1.0):
    batch_size = n_positive * (1 + negative_ratio)
    batch = np.zeros((batch_size, 3))

    neg_label = -1

    while True:
        for idx, (book_id, link_id) in enumerate(random.sample(pairs_list, n_positive)):
            batch[idx, :] = (book_id, link_id, 1)

        idx += 1

        while idx < batch_size:
            random_book = random.randrange(len(books))
            random_link = random.randrange(len(wikilink_name_to_id))

            if (random_book, random_link) not in pairs_set:
                batch[idx, :] = (random_book, random_link, neg_label)
                idx += 1

        np.random.shuffle(batch)
        yield {"book": batch[:, 0], "link": batch[:, 1]}, batch[:, 2]
