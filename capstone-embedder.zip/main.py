# Standard library
import random

# Third-party
import keras
import numpy as np
import pandas as pd
from keras.layers import Dense, Dot, Embedding, Input, Reshape
from keras.models import Model

# First-party/Local
import config
import my_data
import my_model

if __name__ == "__main__":

    # note: `produce_pairs` also populates some global dictionaries such as `books_id_to_name`,
    #     so it has to be run first.
    pairs_list, pairs_set = my_data.produce_pairs(config.MINIMUM_FREQUENCY_FOR_WIKILINKS)

    # create model
    model = my_model.book_embedding_model()
    print(model.summary())

    # train model
    gen = my_data.generate_batch(pairs_list, pairs_set, config.num_positive, negative_ratio=2)
    h = model.fit(gen, epochs=15, steps_per_epoch=len(pairs_list) // config.num_positive, verbose=2)

    # save model
    model.save("model3.h5")

    # # optionally, do a quick demo to verify the model's working
    # model = keras.models.load_model("model3.h5")
    # book_weights = model.get_layer("book_embedding").get_weights()[0]
    # book_weights = book_weights / np.linalg.norm(book_weights, axis=1).reshape((-1, 1))
    # my_model.find_similar("The Lion, the Witch and the Wardrobe", book_weights)
