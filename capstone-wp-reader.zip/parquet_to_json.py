# Standard library
import json
import os
import pathlib
import re
from collections import Counter

# Third-party
import pandas as pd

# First-party/Local
import config
import text_utils

books_json_filename = "books.json"
wikilinks_json_filename = "wikilinks.json"


def convert_parquet_to_json():

    num_articles = 0
    num_redirect_articles = 0
    num_infobox_book_articles = 0
    books_accumulator = ""

    infobox_fields = [
        "name",
        "author",
        "country",
        "language",
        "genre",
        "published",
        "pub_date",
        "isbn",
        "dewey",
        "congress",
        "oclc",
    ]
    infobox_fields_dict = {field: re.compile(r"\| " + field + r"\s+= (.*)\n") for field in infobox_fields}

    wikilinks_counter = Counter()

    firehose_fields = []

    with open(os.path.join(config.json_destination_dir, books_json_filename), mode="w", encoding="utf-8") as fout:
        fout.write('{"books":\n[\n')

    cur_book_id = 1

    for each_parquet_file in pathlib.Path(config.PQ_DIR).glob("*.parquet"):
        df = pd.read_parquet(each_parquet_file)
        df.reset_index()
        for _, row in df.iterrows():
            if not row["article"]:
                continue
            num_articles += 1
            if row["article"][0:9] == "#REDIRECT":
                num_redirect_articles += 1
            elif "{{Infobox book" in row["article"]:
                num_infobox_book_articles += 1

                this_record = dict()
                this_record["book_id"] = 0

                for x in infobox_fields_dict.items():
                    m = x[1].search(row["article"])
                    if m:
                        if m.group(1) and len(m.group(1)) > 0:
                            firehose_fields.append(m.group(1))
                            this_record[x[0]] = text_utils.sanitize_field_value(m.group(1)).strip(
                                text_utils.chars_to_strip
                            )
                            if not this_record[x[0]]:
                                this_record[x[0]] = "not_found"
                        else:
                            this_record[x[0]] = "not_found"
                    else:
                        this_record[x[0]] = "not_found"

                if this_record["name"] and this_record["name"] != "not_found":
                    this_record["wikilinks"] = text_utils.get_all_wikilinks(row["article"])
                    if this_record["wikilinks"]:
                        wikilinks_counter.update(this_record["wikilinks"])

                        this_record["book_id"] = cur_book_id
                        cur_book_id += 1
                        datum = f"""
                            {{\"book_id\": {this_record["book_id"]}, "book_data":
                                    {json.dumps(this_record)}
                            }},\n
                            """
                        books_accumulator += datum

            if num_articles % 1_000_000 == 0:
                print(f"number of articles so far: {num_articles}")
                print(f"number of infobox book/series so far: {num_infobox_book_articles}")
                print(f"number of redirect articles so far: {num_redirect_articles}")
                print(f"number of non-redirect articles so far: {num_articles - num_redirect_articles}")
                with open(books_json_filename, mode="a", encoding="utf-8") as fout:
                    fout.write(books_accumulator)
                books_accumulator = ""

    with open(books_json_filename, mode="a", encoding="utf-8") as fout:
        fout.write('{"book_id": 0, "book_data": { "name": "-", "wikilinks": [] } }\n]\n}\n')

    cur_link_id = 1
    with open(wikilinks_json_filename, mode="w", encoding="utf-8") as fout:
        fout.write('{ "wikilinks":\n[\n')
        for x in wikilinks_counter.most_common():
            datum = f"""
                {{\"link_id\": {cur_link_id}, "wikilink":
                    {{
                        "content": {json.dumps(x[0])},
                        "frequency": {x[1]}
                    }}
                }},\n
                """
            fout.write(datum)
            cur_link_id += 1
        fout.write('{"link_id": 0, "wikilink": { "content": "-", "frequency": 0 } }\n]\n}')

    with open("firehose_fields.txt", mode="w", encoding="utf-8") as fout:
        for x in firehose_fields:
            fout.write(f"{x}\n")

    print("TOTALS:")
    print(f"number of articles: {num_articles}")
    print(f"number of infobox book/series: {num_infobox_book_articles}")
    print(f"number of redirect articles: {num_redirect_articles}")
    print(f"number of non-redirect articles: {num_articles - num_redirect_articles}")
