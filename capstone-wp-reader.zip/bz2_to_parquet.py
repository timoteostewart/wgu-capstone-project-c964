# Standard library
import bz2
import io
import os
from bz2 import BZ2Decompressor
from multiprocessing import Pool

# Third-party
import numpy as np
import pandas as pd
import tqdm
from lxml import etree
from tqdm import tqdm

# First-party/Local
import config

BASE_DIR = "D:/data/WP/"
articles_file = f"enwiki-20220701-pages-articles-multistream.xml.bz2"
articles_full_path = os.path.join(BASE_DIR, articles_file)
index_file = f"enwiki-20220701-pages-articles-multistream-index.txt.bz2"
index_full_path = os.path.join(BASE_DIR, index_file)
index_file_clean = f"enwiki-20220701-pages-articles-multistream-index-just-offsets.txt"
index_clean_full_path = os.path.join(BASE_DIR, index_file_clean)

num_processors_to_use = 8
num_parallel_blocks_to_process = 20


def generate_page_offsets():
    page_offset = []
    last_offset = None
    with open(index_full_path, "rb") as fin:
        bz_data = bz2.decompress(fin.read()).split(b"\n")
        if bz_data[-1] == b"":
            bz_data = bz_data[:-1]
        for line in tqdm(bz_data):
            offset = line.decode().split(":", 1)[0]
            if last_offset != offset:
                last_offset = offset
                page_offset.append(int(offset))

    with open(index_clean_full_path, mode="w", encoding="utf-8") as fin:
        fin.write("\n".join([str(i) for i in page_offset]))

    return page_offset


def get_bz2_byte_str(articles_full_path, offsets):
    with open(articles_full_path, "rb") as fin:
        last_offset = offsets[0]
        fin.read(last_offset)
        for next_offset in offsets[1:]:
            offset = next_offset - last_offset
            last_offset = next_offset
            yield fin.read(offset)


def chunks(input_list, chunk_size):
    for i in range(0, len(input_list), chunk_size):
        yield input_list[i : i + chunk_size]


def _process_parallel(list_bytes):
    df = pd.concat([get_articles(article) for article in list_bytes])
    output_path = os.path.join(config.PQ_DIR, "{:08d}.parquet".format(df["index"].values[0]))
    df.to_parquet(output_path, compression="snappy", index=False)
    del df


def get_articles(byte_string_compressed):
    def _get_text(list_xml_elem):
        return [elem.text for elem in list_xml_elem]

    def _get_id(list_xml_elem):
        return [int(elem.text) for elem in list_xml_elem]

    bz2d = BZ2Decompressor()
    byte_string = bz2d.decompress(byte_string_compressed)
    doc = etree.parse(io.BytesIO(b"<root> " + byte_string + b" </root>"))

    col_id = _get_id(doc.xpath("*/id"))
    col_title = _get_text(doc.xpath("*/title"))
    col_article = _get_text(doc.xpath("*/revision/text"))

    df = pd.DataFrame([col_id, col_title, col_article], index=["index", "title", "article"]).T
    df["index"] = df["index"].astype(np.int32)
    return df


def create_parquet_files():
    offsets = generate_page_offsets()
    queue = []
    for bit_str in tqdm(get_bz2_byte_str(articles_full_path, offsets), total=len(offsets)):
        if len(queue) < num_processors_to_use * num_parallel_blocks_to_process:
            queue.append(bit_str)
        else:
            with Pool(processes=num_processors_to_use) as pool:
                tuple(pool.imap_unordered(_process_parallel, chunks(queue, num_parallel_blocks_to_process)))
            for elem in queue:
                del elem
            queue.clear()
    with Pool(processes=num_processors_to_use) as pool:
        tuple(pool.imap_unordered(_process_parallel, chunks(queue, num_parallel_blocks_to_process)))
    for elem in queue:
        del elem
    queue.clear()
