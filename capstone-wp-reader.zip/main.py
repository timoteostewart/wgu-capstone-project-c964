# First-party/Local
import bz2_to_parquet
import parquet_to_json

if __name__ == "__main__":

    # extract 6.5 million Wikipedia articles from the 20 GB Wikipedia dump
    #     and store them in a sequence of parquet files for easier handling
    bz2_to_parquet.create_parquet_files()

    # iterate the Wikipedia articles sequentially using the parquet files
    #     and for articles that have an "{{Infobox book", extract the wikilinks
    #     and append a record of each article's wikilinks in `books.json`
    parquet_to_json.convert_parquet_to_json()
