# Standard library
import re

wikilink_re = re.compile("\[\[.*?\]\]")

closed_up_initials = re.compile("^([a-z])\.([a-z])\. ")

disallowed_entire_wikilinks = set()
with open("disallowed_entire_wikilinks.txt", mode="r", encoding="utf-8") as fin:
    for d in fin.readlines():
        if d[-1:] == "\n":
            d = d[0:-1]
        disallowed_entire_wikilinks.add(d.lower())

disallowed_startswith_wikilinks = set()
with open("disallowed_startswith_wikilinks.txt", mode="r", encoding="utf-8") as fin:
    for d in fin.readlines():
        if d[-1:] == "\n":
            d = d[0:-1]
        disallowed_startswith_wikilinks.add(d.lower())

substitutions_firstword_wikilinks = dict()
with open("substitutions_firstword_wikilinks.txt", mode="r", encoding="utf-8") as fin:
    for x in fin.readlines():
        index_of_pipe = x.index("|")
        before = x[slice(0, index_of_pipe)].lower()
        after = x[slice(index_of_pipe + 1, len(x))]
        if after[-1:] == "\n":
            after = after[0:-1]
        substitutions_firstword_wikilinks[before] = after

substitutions_startswith_wikilinks = dict()
with open("substitutions_startswith_wikilinks.txt", mode="r", encoding="utf-8") as fin:
    for x in fin.readlines():
        index_of_pipe = x.index("|")
        before = x[slice(0, index_of_pipe)].lower()
        after = x[slice(index_of_pipe + 1, len(x))]
        if after[-1:] == "\n":
            after = after[0:-1]
        substitutions_startswith_wikilinks[before] = after

substitutions_substring_wikilinks = dict()
with open("substitutions_substring_wikilinks.txt", mode="r", encoding="utf-8") as fin:
    for x in fin.readlines():
        index_of_pipe = x.index("|")
        before = x[slice(0, index_of_pipe)].lower()
        after = x[slice(index_of_pipe + 1, len(x))]
        if after[-1:] == "\n":
            after = after[0:-1]
        substitutions_substring_wikilinks[before] = after

substitutions_html_entities = dict()
with open("substitutions_html_entities.txt", mode="r", encoding="utf-8") as fin:
    for x in fin.readlines():
        index_of_pipe = x.index("|")
        before = x[slice(0, index_of_pipe)].lower()
        after = x[slice(index_of_pipe + 1, len(x))]
        if after[-1:] == "\n":
            after = after[0:-1]
        substitutions_html_entities[before] = after

substitutions_regexes = dict()
with open("substitutions_regexes.txt", mode="r", encoding="utf-8") as fin:
    for x in fin.readlines():
        index_of_pipe = x.index("|")
        regex = x[slice(0, index_of_pipe)].lower()
        result = x[slice(index_of_pipe + 1, len(x))]
        if result[-1:] == "\n":
            result = result[0:-1]
        substitutions_regexes[re.compile(regex)] = result


quote_and_bracket_pairs = {
    '"': '"',
    "'": "'",
    "`": "`",
    "‘": "’",
    "“": "”",
    "[": "]",
    "(": ")",
    "{": "}",
}

just_quote_pairs = {
    '"': '"',
    "'": "'",
    "`": "`",
    "‘": "’",
    "“": "”",
}

just_bracket_pairs = {
    "[": "]",
    "(": ")",
    "{": "}",
}

chars_to_strip = "\r\n\t\f\ \u200e"

bracelink_re = re.compile("\{\{.*?\}\}")


def sanitize_field_value(field):

    m = bracelink_re.findall(field)
    for each_bracelink in m:
        full_bracelink = each_bracelink
        inside_bracelink = full_bracelink[2:-2].strip(chars_to_strip)

        try:
            index_of_pipe = inside_bracelink.index("|")
        except ValueError as e:  # EAFP
            field = field.replace(full_bracelink, "", 1)
        else:
            tag = inside_bracelink[slice(0, index_of_pipe)].strip(chars_to_strip).lower()
            content = inside_bracelink[slice(index_of_pipe + 1, len(inside_bracelink))].strip(chars_to_strip)
            # print(f"tag:     {tag}\ncontent: {content}\norig:    {full_bracelink}\n")
            if tag == "isbn":
                field = field.replace(full_bracelink, content, 1)
            elif tag == "isbnt":
                field = field.replace(full_bracelink, content, 1)
            elif tag == "nowrap":
                field = field.replace(full_bracelink, content, 1)
            elif tag == "noitalic":
                field = field.replace(full_bracelink, content, 1)
            elif tag == "nobr":
                field = field.replace(full_bracelink, content, 1)
            elif tag == "hlist" or tag == "ubl" or tag == "unbulleted" or tag == "unbulletedlist":
                list_of_things = content.split("|")
                res = ""
                for each_thing in list_of_things:
                    res += each_thing.strip(chars_to_strip)
                    res += ", "
                res = res[0:-2]  # remove last comma-and-space
                field = field.replace(full_bracelink, res, 1)
            # elif tag == "plainlist":
            #     list_of_things = content.split("|")
            #     res = ""
            #     for each_thing in list_of_things:
            #         res += each_thing.strip(chars_to_strip)
            #         res += ", "
            #     res = res[0:-2]  # remove last comma-and-space
            #     field = field.replace(full_bracelink, res, 1)
            else:
                field = field.replace(full_bracelink, "", 1)

    replacement_text = field

    m = wikilink_re.findall(field)
    for each_wikilink in m:
        if not each_wikilink:
            continue

        if each_wikilink == "[[]]":
            field = field.replace(each_wikilink, "", 1)
            continue

        replacement_text = each_wikilink

        # remove pipes and hashes
        replacement_text = strip_pipes_and_hashes(replacement_text)
        if replacement_text == "[[]]":
            field = field.replace(each_wikilink, "", 1)
            continue

        # strip brackets
        replacement_text = strip_enclosures(replacement_text, just_bracket_pairs)
        if not replacement_text:
            field = field.replace(each_wikilink, "", 1)
            continue
        field = field.replace(each_wikilink, replacement_text, 1)

    for s in substitutions_html_entities:
        if s in field:
            field = field.replace(s, substitutions_html_entities[s])  # unlimited replacement

    for s in substitutions_regexes.items():
        m = s[0].findall(field)
        for each_hit in m:
            # field = field.replace(each_hit, s[1])  # unlimited replacement
            field = re.sub(s[0], s[1], field, count=1)

    field = strip_enclosures(field, just_quote_pairs)
    if not field:
        return ""

    try:
        iop = field.index("|")
    except ValueError as e:
        pass
    else:
        field = field[slice(0, iop)]

    field.strip(chars_to_strip)

    if field == "USA":
        field = "United States"

    return field


def strip_enclosures(str, enclosures):
    new_str = str.strip(chars_to_strip)
    if len(new_str) > 1:
        while new_str[0] in enclosures:
            # if new_str[0] == "'":
            #     print(f"new_str X{new_str}X, new_str[0] {new_str[0]}, new_str[-1:] {new_str[-1:]}")
            if new_str[-1:] == enclosures[new_str[0]]:
                new_str = new_str[slice(1, len(new_str) - 1)]
                new_str = new_str.strip(chars_to_strip)
                if not new_str:
                    return None
            else:
                break
    return new_str


def strip_pipes_and_hashes(wikilink):
    new_wikilink = wikilink
    special_chars = ["|", "#"]
    for special_char in special_chars:
        try:
            index_of_special_char = new_wikilink.index(special_char)
        except ValueError as e:  # EAFP
            pass
        else:
            new_wikilink = new_wikilink[slice(0, index_of_special_char)] + "]]"
    return new_wikilink


def get_all_wikilinks(article):
    res = []
    m = wikilink_re.findall(article)
    for each_wikilink in m:

        if not each_wikilink:
            continue

        # transform to lowercase
        each_wikilink = each_wikilink.lower()

        # remove pipes and hashes
        each_wikilink = strip_pipes_and_hashes(each_wikilink)
        if not each_wikilink:
            continue
        if each_wikilink == "[[]]":
            continue

        # strip quotes and brackets
        each_wikilink = strip_enclosures(each_wikilink, quote_and_bracket_pairs)
        if not each_wikilink:
            continue

        # apply various substitutions (NB: sometimes they are deletions)
        for s in substitutions_substring_wikilinks:
            if s in each_wikilink:
                each_wikilink = each_wikilink.replace(s, substitutions_substring_wikilinks[s])

        for s in substitutions_html_entities:
            if s in each_wikilink:
                each_wikilink = each_wikilink.replace(s, substitutions_html_entities[s])

        for s in substitutions_startswith_wikilinks:
            if each_wikilink.startswith(s):
                each_wikilink = each_wikilink.replace(s, substitutions_startswith_wikilinks[s], 1)
                each_wikilink = each_wikilink.strip(chars_to_strip)
                break
        if not each_wikilink:
            continue

        try:
            firstword = each_wikilink[slice(0, each_wikilink.index(" "))]
        except ValueError as e:  # EAFP
            pass
        else:
            if firstword in substitutions_firstword_wikilinks:
                each_wikilink = each_wikilink.replace(firstword, substitutions_firstword_wikilinks[firstword], 1)
                each_wikilink = each_wikilink.strip(chars_to_strip)
            if not each_wikilink:
                continue

        for s in substitutions_regexes.items():
            m2 = s[0].findall(each_wikilink)
            for each_hit in m2:
                # each_wikilink = each_wikilink.replace(each_hit, s[1])  # unlimited replacement
                each_wikilink = re.sub(s[0], s[1], each_wikilink, count=1)

        m2 = closed_up_initials.search(each_wikilink)
        if m2:
            each_wikilink.replace(m2.group(0), f"{m2.group(1)}. {m2.group(2)}. ", 1)

        # check for disallowed wikilinks (entire and startswith)
        disallowed = False
        if each_wikilink in disallowed_entire_wikilinks:
            disallowed = True
        else:
            for d in disallowed_startswith_wikilinks:
                if each_wikilink.startswith(d):
                    disallowed = True
                    break

        if not disallowed:
            res.append(my_cap_words(each_wikilink))

    return res


def my_cap_words(title):
    words = title.split()
    res = []
    for word in words:

        new_word = ""
        been_capped = False

        for letter in word:
            if letter == "&":
                new_word += letter
                been_capped = False
            elif letter == "-":
                new_word += letter
                been_capped = False
            elif letter == ".":
                new_word += letter
                been_capped = False
            elif been_capped:
                new_word += letter
                continue
            else:
                # invariant now: been_capped == False
                if letter.isalpha():
                    new_word += letter.upper()
                    been_capped = True
                    continue
                else:
                    new_word += letter

        res.append(new_word)
    return " ".join(res)
