PQ_DIR = "D:/data/WP/wiki_parquet2/"
json_destination_dir = "L:/Dropbox/proj/capstone-wp-reader"
