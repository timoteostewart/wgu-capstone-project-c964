chars_to_strip = ";:?!,.()[]'\""


def singular_plural(number, singular, plural):
    if number == 1:
        return f"{number} {singular}"
    else:
        return f"{number} {plural}"


def sanitize_trie_term(term):
    return term.strip(chars_to_strip).lower()


def match_count_display(len_results_set):
    if len_results_set == 0:
        return "no matches\n"
    else:
        return f"{singular_plural(len_results_set, 'match', 'matches')}\n"
