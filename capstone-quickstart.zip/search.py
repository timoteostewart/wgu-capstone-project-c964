# First-party/Local
import my_data
import text_utils

hits_on_prefix_cache = dict()
hits_on_word_cache = dict()


class TrieNode(object):
    def __init__(self):
        self.letters = dict()  # K = character, V = TrieNode
        self.word_ends_here = False
        self.ids_that_end_here = []


class Trie(object):
    def __init__(self):
        self.rootTrieNode = TrieNode()
        self.contents = []

    def addTupleToTrie(self, a_tuple):
        a_tuple_0_sanitized = text_utils.sanitize_trie_term(a_tuple[0])
        curTrieNode = self.rootTrieNode
        for cur_letter in a_tuple_0_sanitized:
            if cur_letter in curTrieNode.letters:
                curTrieNode = curTrieNode.letters[cur_letter]
            else:
                curTrieNode.letters[cur_letter] = TrieNode()
                curTrieNode = curTrieNode.letters[cur_letter]
        curTrieNode.word_ends_here = True
        curTrieNode.ids_that_end_here.append(a_tuple[1])
        self.contents.extend(a_tuple_0_sanitized)

    def getHitsOnExactWord(self, word):
        word = text_utils.sanitize_trie_term(word)

        if not word:
            return set()

        # check cache first
        if word in hits_on_word_cache:
            return hits_on_word_cache[word]

        res = []
        curTrieNode = self.rootTrieNode
        for cur_letter in word:
            if cur_letter in curTrieNode.letters:
                curTrieNode = curTrieNode.letters[cur_letter]
            else:
                return False

        res = curTrieNode.ids_that_end_here

        hits_on_word_cache[word] = set(res)  # store in cache
        return hits_on_word_cache[word]

    def getHitsOnPrefix(self, prefix):
        prefix = text_utils.sanitize_trie_term(prefix)
        if not prefix:
            return set()
        # check cache first
        if prefix in hits_on_prefix_cache:
            return hits_on_prefix_cache[prefix]

        res = []
        curTrieNode = self.rootTrieNode
        for cur_letter in prefix:
            if cur_letter in curTrieNode.letters:
                curTrieNode = curTrieNode.letters[cur_letter]
            else:
                return False

        def helper(self, prefix, cur_trie_node, res):
            if cur_trie_node.word_ends_here:
                res.extend(cur_trie_node.ids_that_end_here)
            for next_node in cur_trie_node.letters.items():
                helper(self, prefix + next_node[0], next_node[1], res)

        helper(self, prefix, curTrieNode, res)

        hits_on_prefix_cache[prefix] = set(res)  # store in cache
        return hits_on_prefix_cache[prefix]

    def contains(self, word):
        word = text_utils.sanitize_trie_term(word)
        curTrieNode = self.rootTrieNode
        for cur_letter in word:
            if cur_letter in curTrieNode.letters:
                curTrieNode = curTrieNode.letters[cur_letter]
            else:
                return False
        if curTrieNode.word_ends_here == True:
            return True
        else:
            return False


def get_book_trie():
    book_trie = Trie()
    for book in my_data.list_of_book_tuples:
        words_in_slug_name = book[0].split(" ")
        for each_word in words_in_slug_name:
            book_trie.addTupleToTrie(
                (
                    each_word.lower(),
                    book[1],
                )
            )
    return book_trie
