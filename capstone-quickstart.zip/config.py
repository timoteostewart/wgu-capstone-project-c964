cur_selection = ""
cur_selection_book_id = -1
cur_n_similar_books = 10
cur_n_similar_books_ids = []

tk_BEGIN = "1.0"

book_r = None

# strings

search_box_prompt = "Type a book title or author in the search box above"
