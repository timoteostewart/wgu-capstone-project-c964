# Third-party
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.manifold import TSNE

# First-party/Local
import config
import my_data
import my_model


def reduce_dim(weights, n_components=3):
    return TSNE(n_components, learning_rate=200, init="pca", metric="cosine").fit_transform(weights)


def plot_all_genres():

    genres_to_include = [
        "science fiction",
        "novel",
        "non-fiction",
        "fantasy",
        "fantasy novel",
        "historical novel",
        "science fiction novel",
        "fiction",
        "crime novel",
        "children's novel",
    ]

    idx_include = []
    genres = []
    for book in my_data.books:
        bd = book["book_data"]
        if "genre" in bd:
            if bd["genre"].lower() in genres_to_include:
                idx_include.append(book["book_id"])
                genres.append(bd["genre"].lower())
    ints, gen = pd.factorize(genres)

    if config.book_r is None:
        config.book_r = reduce_dim(my_model.book_weights, n_components=2)

    # Plot embedding
    plt.figure(figsize=(10, 8))
    plt.scatter(config.book_r[idx_include, 0], config.book_r[idx_include, 1], c=ints, cmap=plt.cm.tab10)
    # Add colorbar and appropriate labels
    cbar = plt.colorbar()
    cbar.set_ticks([])
    for j, lab in enumerate(gen):
        cbar.ax.text(1, (2 * j + 1) / 2.25, lab, ha="left", va="center")
    cbar.ax.set_title(" ", loc="left")
    plt.title("Scatterplot of the Ten Most-Common Book Genres")
    plt.show()


def plot_same_author():
    if config.cur_selection == "" or config.cur_selection_book_id == -1:
        print("no cur selection")
        return

    author_name = my_data.books_id_to_author[config.cur_selection_book_id]

    idxs_same_author = []
    idxs_other_author = []
    for book in my_data.books:
        bd = book["book_data"]
        if "author" in bd:
            if bd["author"] == author_name:
                idxs_same_author.append(book["book_id"])
            else:
                idxs_other_author.append(book["book_id"])

    if config.book_r is None:
        config.book_r = reduce_dim(my_model.book_weights, n_components=2)

    plt.figure(figsize=(10, 8))
    plt.scatter(config.book_r[idxs_other_author, 0], config.book_r[idxs_other_author, 1], color="#cccc00", zorder=0)
    plt.scatter(config.book_r[idxs_same_author, 0], config.book_r[idxs_same_author, 1], color="#0000ff", zorder=10)
    plt.title(f"{author_name}'s books are blue\nOther books are yellow")
    plt.show()


def plot_similar_books():
    if config.cur_selection == "" or config.cur_selection_book_id == -1:
        return

    # author_name = my_data.books_id_to_author[config.cur_selection_book_id]
    book_title = my_data.books_id_to_name[config.cur_selection_book_id]
    selected_book_id = [config.cur_selection_book_id, config.cur_selection_book_id]
    all_books_ids = list(my_data.book_id_to_display_name.keys())
    similar_books_ids = config.cur_n_similar_books_ids[-config.cur_n_similar_books :]

    if config.book_r is None:
        config.book_r = reduce_dim(my_model.book_weights, n_components=2)

    plt.figure(figsize=(10, 8))
    plt.scatter(config.book_r[all_books_ids, 0], config.book_r[all_books_ids, 1], color="#cccc00", zorder=0)
    plt.scatter(config.book_r[similar_books_ids, 0], config.book_r[similar_books_ids, 1], color="#00cc00", zorder=10)
    plt.scatter(config.book_r[selected_book_id, 0], config.book_r[selected_book_id, 1], color="#0000ff", zorder=20)

    plt.title(f'"{book_title}" is blue\nSimilar books are green\nOther books are yellow')

    plt.show()
